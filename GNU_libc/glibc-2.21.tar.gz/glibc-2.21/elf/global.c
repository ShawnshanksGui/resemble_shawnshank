extern int test (void);

int
main (void)
{
  return test ();
}
