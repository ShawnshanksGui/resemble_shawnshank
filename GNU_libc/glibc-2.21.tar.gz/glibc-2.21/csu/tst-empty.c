/* The most useful C program known to man.  */
static int
do_test (void)
{
  return 0;
}

#define TEST_FUNCTION do_test ()
#include "../test-skeleton.c"
