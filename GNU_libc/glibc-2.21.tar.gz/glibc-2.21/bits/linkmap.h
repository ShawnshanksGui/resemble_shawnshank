struct link_map_machine
  {
    /* empty by default */
  };
